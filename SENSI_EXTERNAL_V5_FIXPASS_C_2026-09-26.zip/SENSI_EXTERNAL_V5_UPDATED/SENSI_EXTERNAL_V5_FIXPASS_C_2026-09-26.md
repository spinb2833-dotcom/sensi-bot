SENSI External V5 Fix Pass C

- Removed automatic TEST MODE entity generation from the live renderer.
- ESP now draws only entities received from the game telemetry channel.
- Added /proc cmdline fallback when `pidof mobi.byss.gun3` is unavailable from the app shell.
- Kept process detection independent from telemetry connection state.
- Replaced obsolete unused Client.cpp memory-scanning implementation with the protocol-only native bridge used by the current CMake build.
- Offline/online internet connectivity is not required for localhost telemetry; however, the game must actually publish the telemetry endpoint for live ESP data.
