# SENSI External V5 — Fix Pass 2026-09-26

## Fixed
- Root PID probing no longer runs `su -c pidof` in a tight loop. Root probing only occurs when root was already verified by `RootAccess`, and no more than once every 5 seconds.
- Root authorization is cached for the app session to avoid repeated root-manager/UID checks.
- Removed the forced `killProcess()` shutdown from the normal task-removed path.
- Added persistent diagnostics under `Download/SENSI_EXTERNAL/`:
  - `sensi_external.log`
  - `sensi_external_diagnostic.sh`
- Diagnostic log records connection/PID state, camera frames, entity coordinates, head/feet positions, health and visibility at low frequency.
- ESP renderer is capped at ~25 FPS and no longer generates demo entities while a real game process is detected but telemetry is unavailable.
- Added support for a game-owned 4x4 view-projection matrix for accurate screen placement.
- Added explicit screen-space Y direction handling and feet coordinates.
- ESP lines terminate at the entity's projected body/feet instead of floating from the top of the screen.
- Panel width/height adapts to the device display for better portability.
- Removed animated panel status blinking, text-to-speech activation effects, floater particles/rotation/timer animation, and login background animation.
- Login music is disabled and shown as a muted `MUSIC • DISABLED` status.
- Theme gallery now has 25 unique accent packs. Each pack is accent + black + white.
- Panel background uses only accent + black.
- Slider track and `SENSI EXTERNAL` title use a static accent + white + black gradient; no shine/glow animation.
- Removed the old Theme > Background color selector section.

## Telemetry placement contract
For the most accurate ESP placement, the game should send either:
1. `entity.screen` / `entity.box` coordinates, or
2. `camera.viewProjection` as 16 floats plus entity world coordinates.

Example camera matrix fields:
`{"camera":{"viewProjection":[...16 numbers...],"matrixOrder":"column-major"}}`

Entity world data may include:
`head:{x,y,z}` and `feet:{x,y,z}`.

## Build note
The project source was checked locally, but Gradle 9.4.1 could not be downloaded in the build environment because `services.gradle.org` was unreachable. No claim of a completed APK build is made here.
