# SENSI External Diagnostic

The external panel now exposes connection state in the header:

- `Waiting for My game...` — `mobi.byss.gun3` is not detected.
- `Game found • connecting...` — the game process exists, but the local telemetry endpoint is not connected yet.
- `Connected` — the localhost telemetry stream is connected.

Telemetry is logged under `SenseiTelemetry` with throttled, structured lines. Example:

```text
FRAME #42 camera=(10.000, 1.600, 3.000) yaw=90.00 pitch=0.00 fov=70.00 localTeam=1 entities=3
ENTITY id=42 name=Enemy team=2 pos=(12.000, 0.000, 15.000) head=(12.000, 1.700, 15.000) health=87.0 visible=true
```

## Script

From a rooted Android/Termux shell:

```sh
sh tools/sensi_external_diagnostic.sh
```

Live log:

```sh
sh tools/sensi_external_diagnostic.sh --live
```

Summary only:

```sh
sh tools/sensi_external_diagnostic.sh --summary
```

Normal mode writes a timestamped log to `/sdcard/Download/` and prints the latest camera/entity coordinate data.
