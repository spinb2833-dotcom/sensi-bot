LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := sensei
LOCAL_SRC_FILES := StubNative.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_LDLIBS := -llog
LOCAL_CPPFLAGS := -std=c++17
include $(BUILD_SHARED_LIBRARY)
