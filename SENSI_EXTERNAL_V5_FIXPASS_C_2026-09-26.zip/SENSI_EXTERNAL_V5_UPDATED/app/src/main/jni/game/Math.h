/*
 SENSI MODS UI-ONLY BUILD
 This native feature/offset workflow is intentionally disabled for now.
 Client.cpp is retained unchanged in the project but is not compiled by the
 current UI-only native bridge.
*/
