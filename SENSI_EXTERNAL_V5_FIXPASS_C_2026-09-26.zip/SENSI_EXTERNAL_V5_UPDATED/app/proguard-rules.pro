# Keep JNI entry points and names used by native code.
-keep class com.sensi.inject.** { *; }
-keepclasseswithmembers class * { native <methods>; }

# Keep Android components discoverable by the manifest.
-keep public class com.sensi.inject.AccessScreen { public <methods>; }
-keep public class com.sensi.inject.OverlayService { public <methods>; }
