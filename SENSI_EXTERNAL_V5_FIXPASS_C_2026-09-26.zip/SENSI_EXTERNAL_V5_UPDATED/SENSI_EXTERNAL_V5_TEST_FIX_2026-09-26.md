SENSI External V5 test-fix pass

User test findings addressed:
- Process detection now drives the top status to Connected immediately after the game PID is found.
- Telemetry socket availability is treated as a separate channel, so a missing localhost endpoint no longer hides the process connection state.
- ESP rendering reduced to ~30 FPS and removed continuous title-gradient invalidation to reduce overlay/game jank.
- World-to-screen fallback corrected: up vector is now forward x right, fixing the previous vertical inversion.
- Optional direct screen-space entity coordinates and bounding boxes are supported through the telemetry payload.
- Theme packs are unique accent + black + white. Default is Red Noir.
- Main panel background now uses exactly two colors: accent + black.
- Debug entity logging reduced to 8 entities at 1-second intervals to reduce log overhead.

The actual in-game enemy placement still requires the game telemetry producer to send valid live entity/camera data.
