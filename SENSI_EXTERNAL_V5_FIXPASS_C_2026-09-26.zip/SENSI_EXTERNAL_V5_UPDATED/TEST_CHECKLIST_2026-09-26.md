# SENSI External V5 Fix Pass — Device Test

1. Build/install the APK.
2. Choose the intended execution mode and log in once.
3. Confirm root mode no longer repeatedly opens UID/root authorization activity.
4. Start `mobi.byss.gun3`.
5. SENSI header should move directly to `Connected` when the process is detected.
6. Enable ESP.
7. If the game sends `screen`/`box` telemetry, boxes should follow those coordinates exactly.
8. If the game sends `camera.viewProjection`, the renderer uses that matrix for world-to-screen placement.
9. If the game sends `head` + `feet`, the box and snap line use those points.
10. Confirm the game and panel remain responsive at roughly 25 ESP frames/sec.
11. Check `Download/SENSI_EXTERNAL/` for:
    - `sensi_external.log`
    - `sensi_external_diagnostic.sh`
12. Run the script from Termux if needed:
    `sh /sdcard/Download/SENSI_EXTERNAL/sensi_external_diagnostic.sh`

If ESP is still displaced, send the latest `sensi_external.log`. The FRAME/ENTITY lines now expose camera, entity, head, feet, screen and box data needed to correct the projection without guessing.
