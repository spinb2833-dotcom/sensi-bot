# SENSI External — game-owned telemetry protocol

SENSI is a separate Android process. It does not read or write the game's memory.
The game you control exposes a localhost TCP endpoint on `127.0.0.1:27091`.

## Game -> SENSI frame
Send one JSON object per line:

```json
{"camera":{"x":0,"y":1.6,"z":0,"yaw":0,"pitch":0,"fov":70},"localTeam":1,"entities":[{"id":42,"name":"Enemy","team":2,"x":1,"y":0,"z":12,"health":87,"visible":true,"head":{"x":1,"y":1.7,"z":12}}]}
```

## SENSI -> game messages

Handshake:

```json
{"type":"hello","client":"SENSI_EXTERNAL","version":2}
```

Feature state:

```json
{"type":"feature","name":"esp","enabled":true}
```

Aim request for the selected entity:

```json
{"type":"aim","entityId":42,"point":{"x":1,"y":1.7,"z":12}}
```

The game is responsible for applying that request through its own supported gameplay/control API.

## Live behavior

If no game endpoint is connected, SENSI draws no entities. Live ESP is never replaced by fabricated targets.
An explicit developer test harness can be added separately when needed.


## Connection indicator

The SENSI panel watches the developer-controlled game package `mobi.byss.gun3` with `pidof` and exposes three UI states:

- `Waiting for My game...`
- `Game found • connecting...`
- `Connected`

The PID is used only as a presence signal for the UI/diagnostics. Telemetry still comes through the localhost JSON endpoint; the external renderer does not read the game process memory.
