# SENSI External V5 update — 2026-09-25

## What changed

- Added top header connection state: `Waiting for My game...`, `Game found • connecting...`, and `Connected`.
- Added automatic package presence detection for `mobi.byss.gun3` using `pidof`, with a root fallback.
- Added throttled `SenseiTelemetry` logging for camera, entity position/head coordinates, health, visibility, frame count, and local team.
- Added `tools/sensi_external_diagnostic.sh` to save a timestamped log under `/sdcard/Download/` and print coordinate summaries.
- Added native `SenseiEngine` logging for service/native bridge/toggle events.
- Reworked theme gallery around distinct accent colors with black + white neutrals; no repeated gold/accent colors.
- Reworked actual UI gradients to two color stops instead of three/five-stop mixes.
- Replaced the old red-only panel presets with multiple non-red Noir themes.

## Testing path

1. Start SENSI.
2. Confirm the header says `Waiting for My game...`.
3. Start `mobi.byss.gun3`.
4. Confirm the header progresses to `Game found • connecting...` and then `Connected` once the localhost telemetry endpoint accepts the handshake.
5. Run `sh tools/sensi_external_diagnostic.sh` from a rooted Android/Termux shell to collect the latest coordinate/entity log.
