#!/system/bin/sh
# SENSI External diagnostic helper
BASE="/sdcard/Download/SENSI_EXTERNAL"
LOG="$BASE/sensi_external.log"

echo '=== SENSI EXTERNAL DIAGNOSTIC ==='
echo "Log: $LOG"
echo

echo '-- Latest connection/state lines --'
grep -E 'Connected|Waiting|PID=|telemetry|TEST MODE|FRAME|ENTITY' "$LOG" | tail -80 2>/dev/null

echo
echo '-- Latest coordinates/entities --'
grep 'ENTITY ' "$LOG" | tail -20 2>/dev/null

echo
echo '-- Latest camera frames --'
grep 'FRAME #' "$LOG" | tail -10 2>/dev/null
