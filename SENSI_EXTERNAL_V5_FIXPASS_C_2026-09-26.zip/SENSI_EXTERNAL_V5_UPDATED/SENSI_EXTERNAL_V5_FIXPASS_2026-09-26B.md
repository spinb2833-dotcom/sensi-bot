# SENSI External V5 — Fix Pass B

## Changes
- Stabilized game-process connection state so telemetry socket failures do not make the panel flicker between Connected/Waiting.
- Removed root-manager probing from the hot PID polling loop. Game PID detection uses normal `pidof`; root is not repeatedly requested.
- Telemetry socket retries are throttled and only transition the telemetry-channel log state when that state actually changes.
- Added source screen width/height support for screen-space telemetry so pixel coordinates can be scaled to the overlay's current display.
- Kept world-to-screen and explicit screen/box telemetry paths; actual live body alignment requires the game to publish camera/entity telemetry.
- Added a real elapsed `MM:SS` timer to the speed floater.
- Removed the bitmap/image icon from the floater and replaced it with a lightweight clock face.
- Kept the panel title animation but reduced it to a low-frequency, title-only redraw.
- Made the main panel background neutral dark instead of theme-bright.
- Kept 25 unique accent theme packs; theme accents affect title/sliders/accents rather than the panel background.
- Replaced the thick SeekBar appearance with a thin 3-color gradient track (accent + white + black).
- Reduced sidebar/card highlight intensity.
- Fixed the diagnostic shell script quoting so `BASE` and `LOG` are valid shell assignments.
- Added a direct `/sdcard/Download/SENSI_EXTERNAL/` script-copy attempt in addition to MediaStore.
- Login music remains explicitly disabled/greyed out.

## Build note
The project was source-validated in this environment, but the Gradle 9.4.1 distribution was not locally available and the environment could not download it. APK compilation therefore remains to be performed by the user's Android/Gradle environment.
